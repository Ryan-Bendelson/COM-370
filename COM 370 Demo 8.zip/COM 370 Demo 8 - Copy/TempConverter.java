//Import the necessary packages
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.control.TextField;

/**
 * TempConverter class is for a temperature conversion GUI tool
 *
 * @author Ryan
 * @version 10/30/2023
 */
public class TempConverter extends Application
{
    //Create private variables for the TempConverter class
    private double temp = 0; //Create a variable to store temperatures
    private Label title = new Label("Temperature Conversion Tool"); //Create a title label
    private TextField tempInput = new TextField(); //Create a TextField to input temperature
    private TextField tempOutput = new TextField(); //Create a TextField to output temperature

    @Override
    public void start(Stage stage)
    {
        //Set minimum widths for the TextFields
        tempInput.setPrefWidth(200); //Set the preferred width of the tempInput TextField
        tempOutput.setPrefWidth(200); //Set the preferred width of the tempOutput TextField
        tempInput.setMinWidth(200); //Set the minimum width of the tempInput TextField
        tempOutput.setMinWidth(200); //Set the minimum width of the tempOutput TextField
        
        //Set start text of each pane object
        tempInput.setText("Temperature Input");
        tempOutput.setText("Temperature Output");
        
        //Create a Button for Fahrenheit to Celsius conversion
        Button buttonFC = new Button("Fahrenheit to Celsius");
        buttonFC.setStyle("-fx-border-color: #000000; -fx-border-width: 1px;"); //Set the style of buttonFC
        
        //Create a Button for Celsius to Fahrenheit Conversion
        Button buttonCF = new Button("Celsius to Fahrenheit");
        buttonCF.setStyle("-fx-border-color: #000000; -fx-border-width: 1px;"); //Set the style of buttonCF

        //Create a new grid pane
        GridPane pane = new GridPane();
        pane.setPadding(new Insets(10, 10, 10, 10));
        pane.setMinSize(100, 100);
        pane.setVgap(10);
        pane.setHgap(10);

        //Set an action on buttonFC using method reference
        buttonFC.setOnAction(this::buttonFCClick);
        
        //Set an action on buttonCF using method reference
        buttonCF.setOnAction(this::buttonCFClick);

        //Add Label title to the pane
        pane.add(title, 0, 0, 2, 1);
        
        //Add buttonFC to the pane
        pane.add(buttonFC, 0, 1);
        
        //Add buttonCF to the pane
        pane.add(buttonCF, 0, 2);
        
        //Add tempInput to the pane
        pane.add(tempInput, 1, 1);
        
        //Add tempOutput to the pane
        pane.add(tempOutput, 1, 2);

        //JavaFX must have a Scene (window content) inside a Stage (window)
        Scene scene = new Scene(pane, 400,150);
        stage.setTitle("Temperature Converter");
        stage.setScene(scene);

        //Show the Stage (window)
        stage.show();
    }

    //Create a method to make buttonFC work
    private void buttonFCClick(ActionEvent event)
    {
        temp = Double.parseDouble(tempInput.getText()); //Set temp to have the input of the tempInput TextField
        temp = (temp - 32) * 5 / 9; //Convert temp from Fahrenheit to Celsius
        String display = String.format("Degrees Celsius: %.1f", temp); //Create a String variable to nicely display the Celsius temperature
        tempOutput.setText(display); //Display the Celsius temperature
    }
    
    //Create a method to make buttonCF work
    private void buttonCFClick(ActionEvent event)
    {
        temp = Double.parseDouble(tempInput.getText()); //Set temp to have the input of the tempInput TextField
        temp = (temp * 9 / 5) + 32; //Convert temp from Celsius to Fahrenheit
        tempOutput.setText(String.format("Degrees Fahrenheit: %.1f", temp)); //Display the Fahrenheit temperature
    }
}
