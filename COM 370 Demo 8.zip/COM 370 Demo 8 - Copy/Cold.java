

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.control.TextField;

/**
 * Write a description of JavaFX class Cold here.
 *
 * @author Ryan
 * @version 10/25/2023
 */
public class Cold extends Application
{
    // We keep track of the count, and label displaying the count:
    private int count = 0;
    private Label myLabel = new Label("0");
    
    // Create a Textfield for number entry
    private TextField textInput = new TextField();

    /**
     * The start method is the main entry point for every JavaFX application. 
     * It is called after the init() method has returned and after 
     * the system is ready for the application to begin running.
     *
     * @param  stage the primary stage for this application.
     */
    @Override
    public void start(Stage stage)
    {
        // Create a Button or any control item
        Button myButton = new Button("Count");
        
        // Create a reset Button
        Button newButton = new Button("Reset");
        
        // Create a Baba Button
        Button babaButton = new Button("Baba");

        // Create a new grid pane
        GridPane pane = new GridPane();
        pane.setPadding(new Insets(10, 10, 10, 10));
        pane.setMinSize(300, 200);
        pane.setVgap(10);
        pane.setHgap(10);

        //set an action on the button using method reference
        myButton.setOnAction(this::buttonClick);
        
        //set an action on the newButton using method reference
        newButton.setOnAction(this::newButtonClick);
        
        //set an action on the babaButton using method reference
        babaButton.setOnAction(this::babaButtonClick);

        // Add the button and label into the pane
        pane.add(myLabel, 1, 0);
        pane.add(myButton, 0, 0);
        
        // Add the reset Button to the pane
        pane.add(newButton, 0, 1);
        
        // Add the Baba Button to the pane
        pane.add(babaButton, 1, 1);
        
        // Add the TextField to the pane
        pane.add(textInput, 1, 2);

        // JavaFX must have a Scene (window content) inside a Stage (window)
        Scene scene = new Scene(pane, 300,200);
        stage.setTitle("JavaFX Example");
        stage.setScene(scene);

        // Show the Stage (window)
        stage.show();
    }

    /**
     * This will be executed when the button is clicked
     * It increments the count by 1
     */
    private void buttonClick(ActionEvent event)
    {
        // Counts number of button clicks and shows the result on a label
        count = count + 1;
        myLabel.setText(Integer.toString(count));
    }
    
    // Create a method to make the reset Button work
    private void newButtonClick(ActionEvent event)
    {
        // Resets the number of button clicks to zero
        count = 0;
        myLabel.setText(Integer.toString(count));
    }
    
    // Create a method to make the Baba Button work
    private void babaButtonClick(ActionEvent event)
    {
        int numBagels = Integer.parseInt(textInput.getText());
        String labelText = String.format("Bagel cost : $%5.2f", 1.17 * numBagels);
        myLabel.setText(labelText);
    }
}
