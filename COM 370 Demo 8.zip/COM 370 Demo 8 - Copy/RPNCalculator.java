//Import the necessary packages
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 * RPNCalculator class is for a Body Mass Index GUI calculator
 *
 * @author Ryan
 * @version 11/13/2023
 */
public class RPNCalculator extends Application
{
    //Create private variables for the RPNCalculator class
    private double[] calcStack = {0, 0, 0, 0}; //Create an array to store numbers T, Z, Y, and X
    private TextField elementT = new TextField(); //Create a TextField to display number T
    private TextField elementZ = new TextField(); //Create a TextField to display number Z
    private TextField elementY = new TextField(); //Create a TextField to display number Y
    private TextField elementX = new TextField(); //Create a TextField to display number X
    private boolean clearX = true; //Create a variable to keep track of whether elementX should be cleared
    private boolean pushX = true; //Create a variable to keep track of whether the number in elementX should be pushed before being cleared
    private double numberW = 0; //Create a double to store number W
    private TextField elementW = new TextField(); //Create a master display TextField
    private int trigMode = 0; //Create a variable to store which mode of trigonometric functions to use
    private String[] trigModes = {"Degree", "Radian", "Arc"}; //Create a variable to store the names of the trigonometric function modes
    private HBox hBox1 = new HBox();
    private HBox hBox2 = new HBox();
    private HBox hBox3 = new HBox();
    private HBox hBox4 = new HBox();
    private VBox vBox1 = new VBox();
    private VBox vBox2 = new VBox();
    

    @Override
    public void start(Stage stage)
    {
        //Set the widths of the TextFields
        elementT.setPrefWidth(200); //Set the preferred width of the elementT TextField
        elementZ.setPrefWidth(200); //Set the preferred width of the elementZ TextField
        elementY.setPrefWidth(200); //Set the preferred width of the elementY TextField
        elementX.setPrefWidth(200); //Set the preferred width of the elementX TextField
        elementW.setPrefWidth(200); //Set the preferred width of the elementW TextField
        elementT.setMinWidth(200); //Set the minimum width of the elementT TextField
        elementZ.setMinWidth(200); //Set the minimum width of the elementZ TextField
        elementY.setMinWidth(200); //Set the minimum width of the elementY TextField
        elementX.setMinWidth(200); //Set the minimum width of the elementX TextField
        elementW.setMinWidth(200); //Set the minimum width of the elementW TextField
        elementT.setMaxWidth(200); //Set the maximum width of the elementT TextField
        elementZ.setMaxWidth(200); //Set the maximum width of the elementZ TextField
        elementY.setMaxWidth(200); //Set the maximum width of the elementY TextField
        elementX.setMaxWidth(200); //Set the maximum width of the elementX TextField
        elementW.setMaxWidth(200); //Set the maximum width of the elementW TextField
        
        //Set the starting text of each pane object
        elementT.setText("" + calcStack[0]);
        elementZ.setText("" + calcStack[1]);
        elementY.setText("" + calcStack[2]);
        elementX.setText("" + calcStack[3]);
        elementW.setText("W = " + numberW);
        
        //Create the necessary Buttons for the RPNCalculator class
        Button showButton = new Button("SHOW"); //Create a Button to show every number in calcStack
        Button pushButton = new Button("ENTER"); //Create a Button to push a number onto the calcStack
        Button popButton = new Button("RELEASE"); //Create a Button to pop a number off of the calcStack
        Button additionButton = new Button("+"); //Create a Button to perform addition
        Button subtractionButton = new Button("-"); //Create a Button to perform subtraction
        Button multiplicationButton = new Button("*"); //Create a Button to perform multiplication
        Button divisionButton = new Button("/"); //Create a Button to perform division
        Button modulusButton = new Button("%"); //Create a Button to perform modulus
        Button exponentButton = new Button("X^Y"); //Create a Button to perform exponentiation
        Button sineButton = new Button("SIN()"); //Create a Button to perform sine
        Button cosineButton = new Button("COS()"); //Create a Button to perform cosine
        Button tangentButton = new Button("TAN()"); //Create a Button to perform tangent
        Button trigButton = new Button("TRIG"); //Create a Button to change the mode of trigonometric function buttons
        Button commonLogButton = new Button("LOG"); //Create a Button to perform common log
        Button naturalLogButton = new Button("LN"); //Create a Button to perform natural log
        Button eulerButton = new Button("e^X"); //Create a Button to perform natural number exponentiation
        Button squareRootButton = new Button("SQRT"); //Create a Button to perform square rooting
        Button cubeRootButton = new Button("CBRT"); //Create a Button to perform cube rooting
        Button reciprocalButton = new Button("1/X"); //Create a Button to perform reciprocal
        Button clearButton = new Button("CLEAR"); //Create a Button to set every number in calcStack to zero
        Button clearXButton = new Button("CLRX"); //Create a Button to set the number in elementX to zero
        Button zeroButton = new Button("0"); //Create a Button to input zero into elementX
        Button oneButton = new Button("1"); //Create a Button to input one into elementX
        Button twoButton = new Button("2"); //Create a Button to input two into elementX
        Button threeButton = new Button("3"); //Create a Button to input three into elementX
        Button fourButton = new Button("4"); //Create a Button to input four into elementX
        Button fiveButton = new Button("5"); //Create a Button to input five into elementX
        Button sixButton = new Button("6"); //Create a Button to input six into elementX
        Button sevenButton = new Button("7"); //Create a Button to input seven into elementX
        Button eightButton = new Button("8"); //Create a Button to input eight into elementX
        Button nineButton = new Button("9"); //Create a Button to input nine into elementX
        Button decimalButton = new Button("."); //Create a Button to input a decimal point into elementX
        Button negationButton = new Button("CHS"); //Create a Button to negate the number in elementX
        Button piButton = new Button("PI"); //Create a Button to put the value of pi into elementX
        Button deleteButton = new Button("DELETE"); //Create a Button to delete the last character in elementX
        Button swapButton = new Button("SWAP"); //Create a Button to swap the numbers of elementX and elementY
        Button cycleButton = new Button("CYCLE"); //Create a Button to cycle the calcStack numbers down by one
        Button storeWButton = new Button("STO W"); //Create a Button to store a number as numberW
        Button useWButton = new Button("USE W"); //Create a Button to use numberW in elementX
        
        //Set the width of pushButton
        pushButton.setPrefWidth(100); //Set the preferred width of pushButton
        pushButton.setMinWidth(100); //Set the minimum width of pushButton
        pushButton.setMaxWidth(100); //Set the maximum width of pushButton
        
        //Put the number Buttons in the HBoxes
        hBox1.getChildren().add(oneButton);
        hBox1.getChildren().add(twoButton);
        hBox1.getChildren().add(threeButton);
        hBox2.getChildren().add(fourButton);
        hBox2.getChildren().add(fiveButton);
        hBox2.getChildren().add(sixButton);
        hBox3.getChildren().add(sevenButton);
        hBox3.getChildren().add(eightButton);
        hBox3.getChildren().add(nineButton);
        hBox4.getChildren().add(zeroButton);
        hBox4.getChildren().add(decimalButton);
        hBox4.getChildren().add(piButton);
        
        //Put the arithmetic operation Buttons in vBox1
        vBox1.getChildren().add(additionButton);
        vBox1.getChildren().add(subtractionButton);
        vBox1.getChildren().add(multiplicationButton);
        vBox1.getChildren().add(divisionButton);
        vBox1.getChildren().add(modulusButton);
        
        //Put the trigonometric function Buttons in vBox2
        vBox2.getChildren().add(sineButton);
        vBox2.getChildren().add(cosineButton);
        vBox2.getChildren().add(tangentButton);
        vBox2.getChildren().add(trigButton);
        vBox2.getChildren().add(negationButton);
        
        //Create a new grid pane
        GridPane pane = new GridPane();
        pane.setPadding(new Insets(10, 10, 10, 10));
        pane.setMinSize(100, 100);
        pane.setVgap(10);
        pane.setHgap(10);
        
        //Set an actions on the Buttons using method references
        showButton.setOnAction(this::showButtonClick); //Set an action on showButton using method reference
        pushButton.setOnAction(this::pushButtonClick); //Set an action on pushButton using method reference
        popButton.setOnAction(this::popButtonClick); //Set an action on popButton using method reference
        additionButton.setOnAction(this::additionButtonClick); //Set an action on additionButton using method reference
        subtractionButton.setOnAction(this::subtractionButtonClick); //Set an action on subtractionButton using method reference
        multiplicationButton.setOnAction(this::multiplicationButtonClick); //Set an action on multiplicationButton using method reference
        divisionButton.setOnAction(this::divisionButtonClick); //Set an action on divisionButton using method reference
        modulusButton.setOnAction(this::modulusButtonClick); //Set an action on modulusButton using method reference
        exponentButton.setOnAction(this::exponentButtonClick); //Set an action on exponentButton using method reference
        sineButton.setOnAction(this::sineButtonClick); //Set an action on sineButton using method reference
        cosineButton.setOnAction(this::cosineButtonClick); //Set an action on cosineButton using method reference
        tangentButton.setOnAction(this::tangentButtonClick); //Set an action on tangentButton using method reference
        trigButton.setOnAction(this::trigButtonClick); //Set an action on trigButton using method reference
        commonLogButton.setOnAction(this::commonLogButtonClick); //Set an action on commonLogButton using method reference
        naturalLogButton.setOnAction(this::naturalLogButtonClick); //Set an action on naturalLogButton using method reference
        eulerButton.setOnAction(this::eulerButtonClick); //Set an action on eulerButton using method reference
        squareRootButton.setOnAction(this::squareRootButtonClick); //Set an action on squareRootButton using method reference
        cubeRootButton.setOnAction(this::cubeRootButtonClick); //Set an action on cubeRootButton using method reference
        reciprocalButton.setOnAction(this::reciprocalButtonClick); //Set an action on reciprocalButton using method reference
        clearButton.setOnAction(this::clearButtonClick); //Set an action on clearButton using method reference
        clearXButton.setOnAction(this::clearXButtonClick); //Set an action on clearXButton using method reference
        zeroButton.setOnAction(this::zeroButtonClick); //Set an action on zeroButton using method reference
        oneButton.setOnAction(this::oneButtonClick); //Set an action on oneButton using method reference
        twoButton.setOnAction(this::twoButtonClick); //Set an action on twoButton using method reference
        threeButton.setOnAction(this::threeButtonClick); //Set an action on threeButton using method reference
        fourButton.setOnAction(this::fourButtonClick); //Set an action on fourButton using method reference
        fiveButton.setOnAction(this::fiveButtonClick); //Set an action on fiveButton using method reference
        sixButton.setOnAction(this::sixButtonClick); //Set an action on sixButton using method reference
        sevenButton.setOnAction(this::sevenButtonClick); //Set an action on sevenButton using method reference
        eightButton.setOnAction(this::eightButtonClick); //Set an action on eightButton using method reference
        nineButton.setOnAction(this::nineButtonClick); //Set an action on nineButton using method reference
        decimalButton.setOnAction(this::decimalButtonClick); //Set an action on decimalButton using method reference
        negationButton.setOnAction(this::negationButtonClick); //Set an action on negationButton using method reference
        piButton.setOnAction(this::piButtonClick); //Set an action on piButton using method reference
        deleteButton.setOnAction(this::deleteButtonClick); //Set an action on deleteButton using method reference
        swapButton.setOnAction(this::swapButtonClick); //Set an action on swapButton using method reference
        cycleButton.setOnAction(this::cycleButtonClick); //Set an action on cycleButton using method reference
        storeWButton.setOnAction(this::storeWButtonClick); //Set an action on storeWButton using method reference
        useWButton.setOnAction(this::useWButtonClick); //Set an action on useWButton using method reference
        
        //Add necessary objects to the pane
        pane.add(elementT, 0, 0, 10, 1);
        pane.add(elementZ, 0, 1, 10, 1);
        pane.add(elementY, 0, 2, 10, 1);
        pane.add(elementX, 0, 3, 10, 1);
        pane.add(elementW, 5, 3, 10, 1);
        pane.add(pushButton, 0, 4, 4, 1);
        pane.add(showButton, 5, 4);
        pane.add(popButton, 6, 4);
        pane.add(hBox1, 0, 5, 4, 1);
        pane.add(hBox2, 0, 6, 4 ,1);
        pane.add(hBox3, 0, 7, 4, 1);
        pane.add(hBox4, 0, 8, 4, 1);
        pane.add(vBox1, 5, 5, 1, 5);
        pane.add(vBox2, 6, 5, 1, 5);
        pane.add(exponentButton, 0, 9);
        pane.add(squareRootButton, 5, 9);
        pane.add(cubeRootButton, 6, 9);
        pane.add(commonLogButton, 0, 10);
        pane.add(naturalLogButton, 1, 10);
        pane.add(eulerButton, 2, 10);
        pane.add(reciprocalButton, 3, 10);
        pane.add(clearButton, 0, 11);
        pane.add(clearXButton, 1, 11);
        pane.add(deleteButton, 2, 11);
        pane.add(swapButton, 0, 12);
        pane.add(cycleButton, 1, 12);
        pane.add(storeWButton, 2, 12);
        pane.add(useWButton, 3, 12);

        //JavaFX must have a Scene (window content) inside a Stage (window)
        Scene scene = new Scene(pane, 500,500);
        stage.setTitle("RPN Calculator");
        stage.setScene(scene);

        //Show the Stage (window)
        stage.show();
    }
    
    //Create a method to update the calcStack display TextFields
    private void updateDisplay()
    {
        elementT.setText("" + calcStack[0]);
        elementZ.setText("" + calcStack[1]);
        elementY.setText("" + calcStack[2]);
        elementX.setText("" + calcStack[3]);
    }
    
    //Create a method to make showButton work
    private void showButtonClick(ActionEvent event)
    {
        updateDisplay();
        elementW.setText("W = " + numberW);
    }

    //Create a method to handle pushing a number up the calcStack
    private void stackPush(double push)
    {
        //Get the necessary numbers in the calcStack array
        double z = calcStack[1];
        double y = calcStack[2];
        
        //Shift the elements of the calcStack array up by one discarding number T and taking in push
        calcStack[0] = z;
        calcStack[1] = y;
        calcStack[2] = push;
        calcStack[3] = push;
    }
    
    //Create a method to handle popping a number off the calcStack
    private void stackPop()
    {
        //Get the necessary numbers in the calcStack array
        double t = calcStack[0];
        double z = calcStack[1];
        double y = calcStack[2];
        
        //Shift the elements of the calcStack array down by one making elements T and Z the same value and discarding number X
        calcStack[1] = t;
        calcStack[2] = z;
        calcStack[3] = y;
    }
    
    //Create a method to make pushButton work
    private void pushButtonClick(ActionEvent event)
    {
        //Push an number up the calcStack
        double push = getX();
        stackPush(push);
        
        updateDisplay(); //Update the calcStack display TextFields
        clearX = true;
        pushX = false;
    }
    
    //Create a method to make popButton work
    public void popButtonClick(ActionEvent event)
    {
        stackPop(); //Pop an number off the calcStack
        updateDisplay(); //Update the calcStack display TextFields
    }
    
    //Create a method to update the calculator stack with an operation result
    public void updateStack(double result)
    {
        calcStack[3] = result; //Make the operation result the bottom of calcStack
        updateDisplay(); //Update the calcStack display TextFields
        clearX = true; //Result is cleared out by press of a number Button
        pushX = true; //Result is pushed into the stack by press of a number Button
    }
    
    //Create a method to easily get the double input from elementX
    public double getX()
    {
        return Double.parseDouble(elementX.getText());
    }
    
    //Create a method to perform addition
    public void additionButtonClick(ActionEvent event)
    {
        //Perform the addition operation
        double sum = calcStack[2] + getX();
        
        //Update calcStack
        stackPop(); //Pop an number off the calcStack
        updateStack(sum);
    }
    
    //Create a method to perform subtraction
    public void subtractionButtonClick(ActionEvent event)
    {
        //Perform the subtraction operation
        double difference = calcStack[2] - getX();
        
        //Update calcStack
        stackPop(); //Pop an number off the calcStack
        updateStack(difference);
    }
    
    //Create a method to perform multiplication
    public void multiplicationButtonClick(ActionEvent event)
    {
        //Perform the multiplication operation
        double product = calcStack[2] * getX();
        
        //Update calcStack
        stackPop(); //Pop an number off the calcStack
        updateStack(product);
    }
    
    //Create a method to perform division
    public void divisionButtonClick(ActionEvent event)
    {
        if(getX() == 0)
        {
            if(calcStack[2] == 0)
            {
                elementW.setText("Indeterminate");
            }
            else
            {
                elementW.setText("Undefined");
            }
        }
        else
        {
            //Perform the division operation
            double quotient = calcStack[2] / getX();
        
            //Update calcStack
            stackPop(); //Pop an number off the calcStack
            updateStack(quotient);
        }
    }
    
    //Create a method to perform modulus
    private void modulusButtonClick(ActionEvent event)
    {
        if(getX() == 0)
        {
            if(calcStack[2] == 0)
            {
                elementW.setText("Indeterminate");
            }
            else
            {
                elementW.setText("Undefined");
            }
        }
        else
        {
            //Perform the modulus operation
            int quotient = (int)(calcStack[2] / getX()); //Get the whole number quotient
            double remainder = calcStack[2] - (quotient * getX()); //Store the difference between the dividend and the divisor multiplied by the whole number quotient
        
            //Update calcStack
            stackPop(); //Pop an number off the calcStack
            updateStack(remainder);
        }
    }
    
    //Create a method to perform exponentiation
    private void exponentButtonClick(ActionEvent event)
    {
        if(((1 / calcStack[2]) % 2 == 0) && (getX() < 0))
        {
            elementW.setText("No Real Value");
        }
        else
        {
            //Perform the exponent operation
            double power = Math.pow(getX(), calcStack[2]);
        
            //Update calcStack
            stackPop(); //Pop an number off the calcStack
            updateStack(power);
        }
    }
    
    //Create a method to perform sine
    private void sineButtonClick(ActionEvent event)
    {
        elementW.setText(trigModes[trigMode]);
        double sine = 0;
        double input = getX();
        if(trigMode == 0)
        {
            input = Math.toRadians(input);
        }
        if(trigMode == 2)
        {
            if((input >= -1) && (input <= 1))
            {
                sine = Math.asin(input); //Perform the sine operation
            
                updateStack(sine);
            }
            else
            {
                elementW.setText("Invalid Input");
            }
        }
        else
        {
            sine = Math.sin(input); //Perform the sine operation
            
            updateStack(sine);
        }
    }
    
    //Create a method to perform cosine
    private void cosineButtonClick(ActionEvent event)
    {
        elementW.setText(trigModes[trigMode]);
        double cosine = 0;
        double input = getX();
        if(trigMode == 0)
        {
            input = Math.toRadians(input);
        }
        if(trigMode == 2)
        {
            if((input >= -1) && (input <= 1))
            {
                cosine = Math.acos(input); //Perform the cosine operation
            
                updateStack(cosine);
            }
            else
            {
                elementW.setText("Invalid Input");
            }
        }
        else
        {
            cosine = Math.cos(input); //Perform the cosine operation
            
            updateStack(cosine);
        }
    }
    
    //Create a method to perform tangent
    private void tangentButtonClick(ActionEvent event)
    {
        elementW.setText(trigModes[trigMode]);
        double tangent = 0;
        double input = getX();
        if(trigMode == 0)
        {
            input = Math.toRadians(input);
        }
        if(trigMode == 2)
        {
            tangent = Math.atan(input); //Perform the tangent operation
            
            updateStack(tangent);
        }
        else
        {
            tangent = Math.tan(input); //Perform the tangent operation
            
            updateStack(tangent);
        }
    }
    
    //Create a method to make trigButton work
    private void trigButtonClick(ActionEvent event)
    {
        trigMode++;
        if(trigMode > 2)
        {
            trigMode = 0;
        }
        elementW.setText(trigModes[trigMode]);
    }
    
    //Create a method to perform common log
    private void commonLogButtonClick(ActionEvent event)
    {
        if(getX() <= 0)
        {
            elementW.setText("Undefined");
        }
        else
        {
            //Perform the common logarithm operation
            double commonLog = Math.log10(getX());
        
            updateStack(commonLog);
        }
    }
    
    //Create a method to perform natural log
    private void naturalLogButtonClick(ActionEvent event)
    {
        if(getX() <= 0)
        {
            elementW.setText("Undefined");
        }
        else
        {
            //Perform the natural logarithm operation
            double naturalLog = Math.log(getX());
        
            updateStack(naturalLog);
        }
    }
    
    //Create a method to perform natural number exponentiation
    private void eulerButtonClick(ActionEvent event)
    {
        //Perform the natural number exponent operation
        double euler = Math.exp(getX());
        
        updateStack(euler);
    }
    
    //Create a method to perform square rooting
    private void squareRootButtonClick(ActionEvent event)
    {
        if(getX() < 0)
        {
            elementW.setText("No Real Value");
        }
        else
        {
            //Perform the square root operation
            double squareRoot = Math.sqrt(getX());
        
            updateStack(squareRoot);
        }
    }
    
    //Create a method to perform cube rooting
    private void cubeRootButtonClick(ActionEvent event)
    {
        //Perform the cube root operation
        double cubeRoot = Math.cbrt(getX());
        
        updateStack(cubeRoot);
    }
    
    //Create a method to perform reciprocal
    private void reciprocalButtonClick(ActionEvent event)
    {
        if(getX() == 0)
        {
            elementW.setText("Undefined");
        }
        else
        {
            //Perform the reciprocal operation
            double reciprocal = 1 / getX();
        
            updateStack(reciprocal);
        }
    }
    
    //Create a method to clear calcStack
    private void clearButtonClick(ActionEvent event)
    {
        //Set evey element of the calcStack array to zero
        calcStack[0] = 0;
        calcStack[1] = 0;
        calcStack[2] = 0;
        calcStack[3] = 0;
        
        updateDisplay(); //Update the calcStack display TextFields
        elementW.setText("W = " + numberW); //Display numberW
        clearX = true;
    }
    
    //Create a method to clear elementX
    private void clearXButtonClick(ActionEvent event)
    {
        calcStack[3] = 0; //Set the number at the bottom of calcStack to zero
        updateDisplay(); //Update the calcStack display TextFields
        elementW.setText("W = " + numberW); //Display numberW
        clearX = true;
    }
    
    //Create a method to make the number Buttons work
    private void numberButtonClick(int num)
    {
        if(clearX)
        {
            if(pushX)
            {
                stackPush(getX());
                updateDisplay();
            }
            elementX.setText("");
        }
        String xText = elementX.getText();
        xText = xText + num;
        elementX.setText(xText);
        checkLeadingZero();
        calcStack[3] = getX();
        clearX = false;
    }
    
    //Create a method to make zeroButton work
    private void zeroButtonClick(ActionEvent event)
    {
        numberButtonClick(0);
    }
    
    //Create a method to make oneButton work
    private void oneButtonClick(ActionEvent event)
    {
        numberButtonClick(1);
    }
    
    //Create a method to make twoButton work
    private void twoButtonClick(ActionEvent event)
    {
        numberButtonClick(2);
    }
    
    //Create a method to make threeButton work
    private void threeButtonClick(ActionEvent event)
    {
        numberButtonClick(3);
    }
    
    //Create a method to make fourButton work
    private void fourButtonClick(ActionEvent event)
    {
        numberButtonClick(4);
    }
    
    //Create a method to make fiveButton work
    private void fiveButtonClick(ActionEvent event)
    {
        numberButtonClick(5);
    }
    
    //Create a method to make sixButton work
    private void sixButtonClick(ActionEvent event)
    {
        numberButtonClick(6);
    }
    
    //Create a method to make sevenButton work
    private void sevenButtonClick(ActionEvent event)
    {
        numberButtonClick(7);
    }
    
    //Create a method to make eightButton work
    private void eightButtonClick(ActionEvent event)
    {
        numberButtonClick(8);
    }
    
    //Create a method to make nineButton work
    private void nineButtonClick(ActionEvent event)
    {
        numberButtonClick(9);
    }
    
    //Create a method to make decimalButton work
    private void decimalButtonClick(ActionEvent event)
    {
        String xText = elementX.getText();
        if(xText.indexOf(".") < 0)
        {
            xText = xText + ".";
            elementX.setText(xText);
        }
    }
    
    //Create a method to make negationButton work
    private void negationButtonClick(ActionEvent event)
    {
        //Perform the negation operation
        double number = getX();
        if(number != 0) //Make sure that the negation will not be performed on zero
        {
            number *= -1;
        }
        
        calcStack[3] = number; //Update calcStack
        
        updateDisplay(); //Update the calcStack display TextFields
    }
    
    //Create a method to make piButton work
    private void piButtonClick(ActionEvent event)
    {
        //Make pi the last number in the stack
        calcStack[3] = Math.PI; //Update calcStack
        updateDisplay(); //Update the calcStack display TextFields
    }
    
    //Create a method to make deleteButton work
    private void deleteButtonClick(ActionEvent event)
    {
        String xText = elementX.getText();
        if((xText.length() == 2) && (xText.substring(0, 1).equals("-")))
        {
            xText = xText + "1";
        }
        if(xText.length() > 0)
        {
            xText = xText.substring(0, xText.length() - 1);
            elementX.setText(xText);
        }
        if(xText.length() == 0)
        {
            elementX.setText("0");
        }
    }
    
    //Create a method to make swapButton work
    private void swapButtonClick(ActionEvent event)
    {
        //Perform the number swapping
        double temp = calcStack[3];
        calcStack[3] = calcStack[2];
        calcStack[2] = temp;
        
        updateDisplay(); //Update the calcStack display TextFields
    }
    //Create a method to make cycleButton work
    private void cycleButtonClick(ActionEvent event)
    {
        //Perform the number cycling
        double temp = calcStack[3];
        calcStack[3] = calcStack[2];
        calcStack[2] = calcStack[1];
        calcStack[1] = calcStack[0];
        calcStack[0] = temp;
        
        updateDisplay(); //Update the calcStack display TextFields
    }
    
    //Create a method to remove a the leading zero if it is not directly in front of a decimal point
    private void checkLeadingZero()
    {
        String xText = elementX.getText(); //Create a variable to store the display text of elementX
        String tempString = ""; //Create a temporary String variable
        if((xText.length() > 1)) //Check that xText has at least 2 characters
        {
            tempString = "" + xText.charAt(0);
            if(tempString.equals("0")) //Check that xText has a leading zero
            {
                tempString = "" + xText.charAt(1);
                if(!(tempString.equals("."))) //Check that the leading zero of xText is not part of a decimal
                {
                    //Remove the leading zero displayed by elementX
                    xText = xText.substring(1, xText.length()); //Remove the leading zero of xText
                    elementX.setText(xText); //Set elementX to display xText
                }
            }
        }
    }
    
    //Create a method to make storeWButton work
    private void storeWButtonClick(ActionEvent event)
    {
        //Take the number in elementX and store it as numberW
        numberW = getX(); //Get the double from elementX
        elementW.setText("W = " + numberW); //Display numberW
    }
    
    //Create a method to make useWButton work
    private void useWButtonClick(ActionEvent event)
    {
        //Replace the bottom of the calculator stack with numberW
        elementW.setText("W = " + numberW); //Display numberW
        calcStack[3] = numberW; //Put numberW into the bottom of calcStack
        updateDisplay(); //Update the calcStack display TextFields
    }
}
