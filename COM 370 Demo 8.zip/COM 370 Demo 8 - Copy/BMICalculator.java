//Import the necessary packages
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.control.TextField;

/**
 * BMICalculator class is for a Body Mass Index GUI calculator
 *
 * @author Ryan
 * @version 11/5/2023
 */
public class BMICalculator extends Application
{
    //Create private variables for the BMICalculator class
    private Label title = new Label("BMI Calculator"); //Create a title label
    private TextField weightInput = new TextField(); //Create a TextField to input weight
    private TextField heightInput = new TextField(); //Create a TextField to input height
    private TextField bmiOutput = new TextField(); //Create a TextField to output BMI

    @Override
    public void start(Stage stage)
    {
        //Set the widths of the TextFields
        weightInput.setPrefWidth(200); //Set the preferred width of the weightInput TextField
        heightInput.setPrefWidth(200); //Set the preferred width of the heightInput TextField
        weightInput.setMinWidth(200); //Set the minimum width of the weightInput TextField
        heightInput.setMinWidth(200); //Set the minimum width of the heightInput TextField
        
        //Set the starting text of each pane object
        weightInput.setText("Input Weight Here (Pounds)");
        heightInput.setText("Input Height Here (Inches)");
        bmiOutput.setText("BMI Output Here");
        
        //Create a Button to do the calculation
        Button calcButton = new Button("Calculate BMI");
        calcButton.setStyle("-fx-border-color: #000000; -fx-border-width: 1px;"); //Set the style of calcButton
        
        //Create a new grid pane
        GridPane pane = new GridPane();
        pane.setPadding(new Insets(10, 10, 10, 10));
        pane.setMinSize(100, 100);
        pane.setVgap(10);
        pane.setHgap(10);

        //Set an action on calcButton using method reference
        calcButton.setOnAction(this::calcButtonClick);
        
        //Add Label title to the pane
        pane.add(title, 0, 0, 2, 1);
        
        //Add weightInput to the pane
        pane.add(weightInput, 0, 1);
        
        //Add heightInput to the pane
        pane.add(heightInput, 1, 1);
        
        //Add bmiOutput to the pane
        pane.add(bmiOutput, 1, 2);
        
        //Add calcButton to the pane
        pane.add(calcButton, 0, 2);

        //JavaFX must have a Scene (window content) inside a Stage (window)
        Scene scene = new Scene(pane, 500,150);
        stage.setTitle("BMI Calculator");
        stage.setScene(scene);

        //Show the Stage (window)
        stage.show();
    }

    //Create a method to make calcButton work
    private void calcButtonClick(ActionEvent event)
    {
        double weight = Double.parseDouble(weightInput.getText()); //Create a variable to store the inputted weight
        double height = Double.parseDouble(heightInput.getText()); //Create a variable to store the inputted height
        double bmi = (703 * weight) / (height * height); //Create a variable to store the calculated BMI
        bmiOutput.setText(String.format("Your BMI is: %.2f", bmi)); //Display the BMI
    }
}
